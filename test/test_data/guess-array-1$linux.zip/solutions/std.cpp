
#include <bits/stdc++.h>
using namespace std;
int a[5005], n;
int main()
{
    int i, a1, a2, a3;
    scanf("%d", &n);
    printf("? 1 2\n");
    fflush(stdout);
    scanf("%d", &a1);
    printf("? 2 3\n");
    fflush(stdout);
    scanf("%d", &a2);
    printf("? 1 3\n");
    fflush(stdout);
    scanf("%d", &a3);
    a[1] = (a1 + a2 + a3 - 2 * a2) / 2;
    a[2] = (a1 + a2 + a3 - 2 * a3) / 2;
    a[3] = (a1 + a2 + a3 - 2 * a1) / 2;
    for (i = 4; i <= n; i++)
    {
        printf("? 1 %d\n", i);
        fflush(stdout);
        scanf("%d", &a1);
        a[i] = a1 - a[1];
    }
    printf("! ");
    for (i = 1; i <= n; i++)
    {
        printf("%d ", a[i]);
    }
    return 0;
}
