#include "testlib.h"

int main(int argc, char* argv[]) {
    
    registerInteraction(argc, argv);
    int n = inf.readInt();
    
    auto arr = inf.readIntegers(n);
    const int max_requests = n;
    println(n);

    std::string token;
    
    int requests = 0;
    for (;;) {
        token = ouf.readToken("?|!");
        if (token == "?") {
            int x = ouf.readInt(1, n);
            int y = ouf.readInt(1, n);
            if (x == y) {
                quitf(_wa, "x should not equal to y");
            }
            requests++;
            quitif(requests > max_requests, _wa, "too many queries");
            println(arr[x - 1] + arr[y - 1]);
        } else {
            auto res = ouf.readIntegers(n, 1, 100000);
            if (res == arr) {
                quitf(_ok, "ok");
            } else {
                quitf(_wa, "answer is wrong");
            }
        }
    }
}
