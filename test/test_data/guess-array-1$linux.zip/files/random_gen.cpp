#include "testlib.h"

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
    int n = opt<int>("n");
    println(n);
    std::vector<int> a(n);
    for (int i = 0; i < n; i++) {
        a[i] = rnd.next(1, 100000);
    }
    println(a);
}
